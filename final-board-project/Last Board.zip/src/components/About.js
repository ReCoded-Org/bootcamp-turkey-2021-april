import React  from "react";

function About (){
    return (
        <div>
            <h3>This is the About Page</h3>
        </div>
    )
}
export default About